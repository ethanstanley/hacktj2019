package com.example.hacktjproj;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;

public class TransactionActivity extends AppCompatActivity {

    private String mUserName;
    private EditText mEditText;
    private Spinner mSpinner;
    private DatabaseReference myRef;
    private Button myButton;
    private Button goBack;
    private ArrayList<String> mUserPurchase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);


        mSpinner = (Spinner) findViewById(R.id.spinText);
        mEditText = (EditText) findViewById(R.id.editText);

        myButton = (Button) findViewById(R.id.buttonSend);
        goBack = (Button) findViewById(R.id.backker);


        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> add = new ArrayList<String>();
                String[] namesArray = new String[] {mSpinner.getSelectedItem().toString(), mEditText.getText().toString()};
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = preferences.edit();
                String currentVal = preferences.getString(mSpinner.getSelectedItem().toString() + "current", "0");
                int newValue = Integer.parseInt(currentVal) + Integer.parseInt(mEditText.getText().toString());
                editor.putString(mSpinner.getSelectedItem().toString() + "current", newValue+"");
                editor.commit();
            }
        });

        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                setResult(RESULT_OK, i);
                finish();
            }
        });
    }
}
