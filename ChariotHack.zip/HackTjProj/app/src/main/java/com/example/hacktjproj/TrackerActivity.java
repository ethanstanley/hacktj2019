package com.example.hacktjproj;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Arrays;

public class TrackerActivity extends AppCompatActivity implements RecyclerViewAdapter1.ItemClickListener {

    private Button mSettingsButton;
    private Button mTransactionsButton;
    private void createRecyclerView(ArrayList<ArrayList<String>> data) {
        RecyclerView trackerRecyclerView = findViewById(R.id.tracker_categories);
        trackerRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecyclerViewAdapter1 adapter = new RecyclerViewAdapter1(this, data);
        adapter.setClickListener(this);
        trackerRecyclerView.setAdapter(adapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("Fast Foodcurrent", "0");
        editor.putString("Fast Foodtotal", "100");
        editor.putString("Entertainmentcurrent", "0");
        editor.putString("Entertainmenttotal", "100");
        editor.putString("Clothingcurrent", "0");
        editor.putString("Clothingotal", "100");
        editor.putString("Homecurrent", "0");
        editor.putString("Hometotal", "100");
        editor.putString("Groceriescurrent", "0");
        editor.putString("Groceriestotal", "100");
        editor.putString("Personal Carecurrent", "0");
        editor.putString("Personal Caretotal", "100");
        editor.commit();
        String foodcurrent = preferences.getString("Fast Foodcurrent", "0");
        String foodtotal = preferences.getString("Fast Foodtotal", "100");
        String entertainmentcurrent = preferences.getString("Entertainmentcurrent", "0");
        String entertainmenttotal = preferences.getString("Entertainmenttotal", "100");
        String clothingcurrent = preferences.getString("Clothingcurrent", "0");
        String clothingtotal = preferences.getString("Clothingtotal", "100");
        String homecurrent = preferences.getString("Homecurrent", "0");
        String hometotal = preferences.getString("Hometotal", "100");
        String groceriescurrent = preferences.getString("Groceriescurrent", "0");
        String groceriestotal = preferences.getString("Groceriestotal", "100");
        String personalcarecurrent = preferences.getString("Personal Carecurrent", "0");
        String personalcaretotal = preferences.getString("Personal Caretotal", "100");
        ArrayList<String> a = new ArrayList<>(Arrays.asList("Fast Food", foodcurrent, foodtotal));
        ArrayList<String> b = new ArrayList<>(Arrays.asList("Entertainment", entertainmentcurrent,entertainmenttotal));
        ArrayList<String> c = new ArrayList<>(Arrays.asList("Clothing", clothingcurrent, clothingtotal));
        ArrayList<String> d = new ArrayList<>(Arrays.asList("Home", homecurrent, hometotal));
        ArrayList<String> e = new ArrayList<>(Arrays.asList("Groceries", groceriescurrent, groceriestotal));
        ArrayList<String> f = new ArrayList<>(Arrays.asList("Personal Care", personalcarecurrent, personalcaretotal));
        ArrayList<ArrayList<String>> data = new ArrayList<>(Arrays.asList(a, b, c, d, e, f));

        createRecyclerView(data);
        mSettingsButton = (Button) findViewById(R.id.tracker_settings);
        mSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TrackerActivity.this, CategoryForSpending.class);
                startActivityForResult(i, 1);
            }
        });
        mTransactionsButton = (Button) findViewById(R.id.tracker_add);
        mTransactionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TrackerActivity.this, TransactionActivity.class);
                startActivityForResult(i, 1);
            }
        });
    }

    public void onItemClick(View view, int position) {
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            Log.v("HEERRREEEEEEE", "");
            if(resultCode == RESULT_OK){
                Log.v("Hereeeeeeeeee", "");
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = preferences.edit();
                String foodcurrent = preferences.getString("Fast Foodcurrent", "0");
                String foodtotal = preferences.getString("Fast Foodtotal", "100");
                String entertainmentcurrent = preferences.getString("Entertainmentcurrent", "0");
                String entertainmenttotal = preferences.getString("Entertainmenttotal", "100");
                String clothingcurrent = preferences.getString("Clothingcurrent", "0");
                String clothingtotal = preferences.getString("Clothingtotal", "100");
                String homecurrent = preferences.getString("Homecurrent", "0");
                String hometotal = preferences.getString("Hometotal", "100");
                String groceriescurrent = preferences.getString("Groceriescurrent", "0");
                String groceriestotal = preferences.getString("Groceriestotal", "100");
                String personalcarecurrent = preferences.getString("Personal Carecurrent", "0");
                String personalcaretotal = preferences.getString("Personal Caretotal", "100");
                ArrayList<String> a = new ArrayList<>(Arrays.asList("Fast Food", foodcurrent, foodtotal));
                ArrayList<String> b = new ArrayList<>(Arrays.asList("Entertainment", entertainmentcurrent,entertainmenttotal));
                ArrayList<String> c = new ArrayList<>(Arrays.asList("Clothing", clothingcurrent, clothingtotal));
                ArrayList<String> d = new ArrayList<>(Arrays.asList("Home", homecurrent, hometotal));
                ArrayList<String> e = new ArrayList<>(Arrays.asList("Groceries", groceriescurrent, groceriestotal));
                ArrayList<String> f = new ArrayList<>(Arrays.asList("Personal Care", personalcarecurrent, personalcaretotal));
                ArrayList<ArrayList<String>> thing = new ArrayList<>(Arrays.asList(a, b, c, d, e, f));

                createRecyclerView(thing);
            }
        }
    }

}
