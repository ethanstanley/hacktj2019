package com.example.android.hacktj2k19;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.reimaginebanking.api.nessieandroidsdk.NessieError;
import com.reimaginebanking.api.nessieandroidsdk.NessieResultsListener;
import com.reimaginebanking.api.nessieandroidsdk.models.Address;
import com.reimaginebanking.api.nessieandroidsdk.models.Customer;
import com.reimaginebanking.api.nessieandroidsdk.models.PostResponse;
import com.reimaginebanking.api.nessieandroidsdk.requestclients.NessieClient;

public class MainActivity extends AppCompatActivity {
    private Button mGetInfoButton;
    RequestQueue queue;
    private String url, output, input, account;
    private EditText accountNameEditText;
    private TextView mDisplayInfoText;
    private JsonObjectRequest jsonobjectrequest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mGetInfoButton = (Button) findViewById(R.id.load_button);
        mDisplayInfoText = (TextView) findViewById(R.id.display_account);
        accountNameEditText = (EditText) findViewById(R.id.account_name);

        queue = Volley.newRequestQueue(this);

        mGetInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NessieClient client = NessieClient.getInstance("4808e0faa03f5852be84038d057e476d");

                Customer customer = new Customer.Builder()
                        .address(new Address("73", "55", "A-town", "VA", "22222"))
                        .firstName("Reed")
                        .lastName("Hamil")
                        .build();

                client.CUSTOMER.createCustomer(customer, new NessieResultsListener() {
                    @Override
                    public void onSuccess(Object result) {
                        PostResponse<Customer> response = (PostResponse<Customer>) result;
                        Customer customer = response.getObjectCreated();
                        mDisplayInfoText.setText(customer.toString());
                        // do something with the newly created deposit
                    }
                    @Override
                    public void onFailure(NessieError error) {
                        // handle error
                    }
                });

                /*
                JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                        Request.Method.GET,
                        url,
                        null,
                        new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                // Do something with response
                                //mTextView.setText(response.toString());

                                // Process the JSON

                                try{
                                    //WHEN SOMEONE LOGS IN

                                    for(int i=0;i<response.length();i++){
                                        // Get current json object
                                        JSONObject account = response.getJSONObject(i);

                                        // Get the current student (json object) data
                                        String nickname = account.getString("nickname");
                                        Integer balance = account.getInt("balance");
                                        String id = account.getString("_id");

                                        // Display the formatted json data in text view
                                        mDisplayInfoText.append(nickname +" Balance :" + balance +"\nID : " + id);
                                        mDisplayInfoText.append("\n\n");
                                        }

                                }catch (JSONException e){
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener(){
                            @Override
                            public void onErrorResponse(VolleyError error){
                                // Do something when error occurred
                                mDisplayInfoText.setText(error.toString());
                            }
                        }
                );

                // Add JsonArrayRequest to the RequestQueue
                queue.add(jsonArrayRequest);
                */




                /*jsonobjectrequest = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    System.out.println(response.toString());
                                    mDisplayInfoText.setText(response.toString());
//                                    JSONObject myObject = new JSONObject(response);
////                                    output = response.getJSONArray("results").getJSONObject(0).getString("id");
//                                    output = response.toString();
//                                  JsonObject  output2 = JSON.parse(output)
                                } catch (Exception e) {
                                    mDisplayInfoText.setText("This name could not be found. Try again. inner request" + e.getMessage());

                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        mDisplayInfoText.setText("This name could not be found. Try again. outter request" + error.getMessage());
                    }
                });
                queue.add(jsonobjectrequest);*/

            }
        });

    }
}
