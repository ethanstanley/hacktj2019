package com.example.hacktjproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;

public class TrackerActivity extends AppCompatActivity implements RecyclerViewAdapter.ItemClickListener {

    private void createRecyclerView(ArrayList<String> numbers, ArrayList<String> highScores) {
        RecyclerView trackerRecyclerView = findViewById(R.id.tracker_categories);
        trackerRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, highScores);
        adapter.setClickListener(this);
        trackerRecyclerView.setAdapter(adapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);

    }

    public void onItemClick(View view, int position) {
    }

}
