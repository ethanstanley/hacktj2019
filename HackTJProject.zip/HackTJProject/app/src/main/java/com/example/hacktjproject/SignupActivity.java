package com.example.hacktjproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.reimaginebanking.api.nessieandroidsdk.NessieError;
import com.reimaginebanking.api.nessieandroidsdk.NessieResultsListener;
import com.reimaginebanking.api.nessieandroidsdk.models.Address;
import com.reimaginebanking.api.nessieandroidsdk.models.Customer;
import com.reimaginebanking.api.nessieandroidsdk.models.PostResponse;
import com.reimaginebanking.api.nessieandroidsdk.requestclients.NessieClient;

public class SignupActivity extends AppCompatActivity {
    private Button mGetInfoButton;
    private String username;
    private EditText accountNameEditText;
    private EditText accountPasswordEditText;
    private TextView mDisplayInfoText;
    private JsonObjectRequest jsonobjectrequest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        mGetInfoButton = findViewById(R.id.signup_submit);
        mDisplayInfoText = (TextView) findViewById(R.id.signup_test_text_view);
        accountNameEditText = (EditText) findViewById(R.id.signup_username_edittext);
        accountPasswordEditText = (EditText) findViewById(R.id.signup_password_edittext);

//        mGetInfoButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                username = accountNameEditText.getText().toString();
//                NessieClient client = NessieClient.getInstance("4808e0faa03f5852be84038d057e476d");
//
//                Customer customer = new Customer.Builder()
//                        .address(new Address("73", "55", "A-town", "VA", "22222"))
//                        .firstName(username)
//                        .lastName("Hamil")
//                        .build();
//
//                client.CUSTOMER.createCustomer(customer, new NessieResultsListener() {
//                    @Override
//                    public void onSuccess(Object result) {
//                        PostResponse<Customer> response = (PostResponse<Customer>) result;
//                        Customer customer = response.getObjectCreated();
//                        mDisplayInfoText.setText(customer.toString());
//                        // do something with the newly created deposit
//                    }
//                    @Override
//                    public void onFailure(NessieError error) {
//                        // handle error
//                    }
//                });
//            }
//        });

    }
}
