package com.example.hacktjproject;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private ArrayList<ArrayList<String>> mData;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;

    // data is passed into the constructor
    RecyclerViewAdapter(Context context, ArrayList<ArrayList<String>> data) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
    }

    // inflates the row layout from xml when needed
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.tracker_row, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        ArrayList<String> participant = mData.get(position);
        String category = participant.get(0);
        int moneySpent = Integer.parseInt(participant.get(1));
        int moneyAllocated = Integer.parseInt(participant.get(2));
        holder.category.setText(category);
        holder.moneySpent.setText(String.format("Money Spent: $%s", participant.get(1)));
        String moneyDonate = Integer.toString(moneyAllocated - moneySpent);
        holder.moneyDonate.setText(String.format("Projected Donation: $%s", moneyDonate));
        holder.progressBar.setProgress((int) (((float) moneySpent) / ((float) moneyAllocated) * 100));
        Float percentage = ((float) moneySpent) / ((float) moneyAllocated) * 100;
        holder.percentFilled.setText(
                String.format("%s%%", new DecimalFormat("#.#").format(percentage)));
    }

    // total number of rows
    @Override
    public int getItemCount() {
        return mData.size();
    }

    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView category;
        TextView moneySpent;
        TextView moneyDonate;
        ProgressBar progressBar;
        TextView percentFilled;

        ViewHolder(View itemView) {
            super(itemView);
            category = itemView.findViewById(R.id.tracker_row_category);
            moneySpent = itemView.findViewById(R.id.tracker_row_money_spent);
            moneyDonate = itemView.findViewById(R.id.tracker_row_money_donate);
            progressBar = itemView.findViewById(R.id.tracker_row_progress_bar);
            percentFilled = itemView.findViewById(R.id.tracker_row_percent_filled);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }

    }

    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}