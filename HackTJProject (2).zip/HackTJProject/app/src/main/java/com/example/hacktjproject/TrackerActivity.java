package com.example.hacktjproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Arrays;

public class TrackerActivity extends AppCompatActivity implements RecyclerViewAdapter.ItemClickListener {

//    private Button mSettingsButton;
    private void createRecyclerView(ArrayList<ArrayList<String>> data) {
        RecyclerView trackerRecyclerView = findViewById(R.id.tracker_categories);
        trackerRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, data);
        adapter.setClickListener(this);
        trackerRecyclerView.setAdapter(adapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);

        ArrayList<String> a = new ArrayList<>(Arrays.asList("Fast Food", "400", "900"));
        ArrayList<String> b = new ArrayList<>(Arrays.asList("Entertainment", "500", "1200"));
        ArrayList<String> c = new ArrayList<>(Arrays.asList("Clothing", "100", "300"));
        ArrayList<ArrayList<String>> data = new ArrayList<>(Arrays.asList(a, b, c));

        createRecyclerView(data);

//        mSettingsButton = findViewById(R.id.tracker_settings);
//        mSettingsButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(TrackerActivity.this, SetCategoriesActivity.class));
//            }
//        });
    }

    public void onItemClick(View view, int position) {
    }

}
