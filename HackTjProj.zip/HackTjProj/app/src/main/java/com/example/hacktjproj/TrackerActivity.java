package com.example.hacktjproj;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Arrays;

public class TrackerActivity extends AppCompatActivity implements RecyclerViewAdapter1.ItemClickListener {

    private Button mSettingsButton;
    private void createRecyclerView(ArrayList<ArrayList<String>> data) {
        RecyclerView trackerRecyclerView = findViewById(R.id.tracker_categories);
        trackerRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecyclerViewAdapter1 adapter = new RecyclerViewAdapter1(this, data);
        adapter.setClickListener(this);
        trackerRecyclerView.setAdapter(adapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);

        ArrayList<String> a = new ArrayList<>(Arrays.asList("Fast Food", "400", "900"));
        ArrayList<String> b = new ArrayList<>(Arrays.asList("Entertainment", "500", "1200"));
        ArrayList<String> c = new ArrayList<>(Arrays.asList("Clothing", "100", "300"));
        ArrayList<String> d = new ArrayList<>(Arrays.asList("Home", "400", "900"));
        ArrayList<String> e = new ArrayList<>(Arrays.asList("Groceries", "550", "700"));
        ArrayList<String> f = new ArrayList<>(Arrays.asList("Personal Care", "150", "600"));
        ArrayList<ArrayList<String>> data = new ArrayList<>(Arrays.asList(a, b, c, d, e, f));

        createRecyclerView(data);
        mSettingsButton = (Button) findViewById(R.id.tracker_settings);
        mSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TrackerActivity.this, CategoryForSpending.class));
            }
        });
    }

    public void onItemClick(View view, int position) {
    }

}
