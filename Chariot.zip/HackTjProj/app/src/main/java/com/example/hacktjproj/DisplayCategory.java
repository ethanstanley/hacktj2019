package com.example.hacktjproj;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;

public class DisplayCategory extends AppCompatActivity {
    private String mCategory;
    private String mUsername;
    private TextView mCategoryName;
    private FirebaseDatabase database;
    private DatabaseReference myRef;
    private Spinner mCharityText;
    private EditText mMoneyText;
    private String mCharityOfChoice;
    private String mMoneyToDonate;
    private ArrayList<String> mUserInfo;
    private Button saveInfo;
    private Button goBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_category);
        goBack = (Button) findViewById(R.id.activity_charities_goBack);
        saveInfo= (Button) findViewById(R.id.activity_moneycharity_save);
        mCategory = getIntent().getExtras().getString("Category", "Other");
        mUsername = getIntent().getExtras().getString("Username", "John Doe");

        mCategoryName = (TextView) findViewById(R.id.display_category);
        mCategoryName.setText(mCategory);

        mCharityText = (Spinner) findViewById(R.id.spinner1);

        mMoneyText = (EditText) findViewById(R.id.money_month_text);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference(mUsername);


        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.putExtra("category", mCategory);
                setResult(RESULT_OK, i);
                finish();
            }
        });

        saveInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCharityOfChoice = mCharityText.getSelectedItem().toString();
                mMoneyToDonate = mMoneyText.getText().toString();
                String keyyy = myRef.push().getKey();
                ArrayList<String> add = new ArrayList<String>();
                String[] namesArray = new String[] {mCategory, mCharityOfChoice, mMoneyToDonate};
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString(mCategory + "current", "0");
                editor.putString(mCategory + "total", mMoneyToDonate);
                editor.commit();
                mUserInfo  = new ArrayList<String>(Arrays.asList(namesArray));
                myRef.child(keyyy).setValue(mUserInfo);

                Intent i = new Intent();
                i.putExtra("category", mCategory);
                setResult(RESULT_OK, i);
                finish();
            }
        });
    }
}
