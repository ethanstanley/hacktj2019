package com.example.hacktjproj;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Arrays;

public class CategoryForSpending extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener {

    private MyRecyclerViewAdapter adapter;
    private Button mProceed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_for_spending);

        mProceed =(Button) findViewById(R.id.proceed);
                //Used this tutorial - https://stackoverflow.com/questions/40584424/simple-android-recyclerview-example

        //1. Add dependencies - appcompat and recyclerview - used project structure menu
        //2. Added code to XML layout
        /*<android.support.v7.widget.RecyclerView
          android:id="@+id/workshopParticipants"
          android:layout_width="match_parent"
          android:layout_height="match_parent">
          </android.support.v7.widget.RecyclerView>*/
        //3.  Create new xml file for the styling of each individual row
        /*LinearLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="horizontal"
        android:padding="10dp">
        <TextView
        android:id="@+id/personName"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:textSize="20sp"/>
        </LinearLayout>*/
        //4.    Created adapter class - made necessary variable name changes
        //5.    Added code to CategoryForSpending to use adapter

        // data to populate the RecyclerView with
        ArrayList<String> a = new ArrayList<>(Arrays.asList("Fast Food", "Incomplete"));
        ArrayList<String> b = new ArrayList<>(Arrays.asList("Grocery Shopping", "Incomplete"));
        ArrayList<String> c = new ArrayList<>(Arrays.asList("Clothing", "Incomplete"));
        ArrayList<String> d = new ArrayList<>(Arrays.asList("Entertainment", "Incomplete"));
        ArrayList<String> e = new ArrayList<>(Arrays.asList("Personal Care", "Incomplete"));
        ArrayList<String> f = new ArrayList<>(Arrays.asList("Home", "Incomplete"));
        ArrayList<ArrayList<String>> CategoryList = new ArrayList<>(Arrays.asList(a, b, c, d, e, f));

        // set up the RecyclerView
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.workshopParticipants);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, CategoryList);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);

        mProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                setResult(RESULT_OK, i);
                finish();
            }
        });
    }

    @Override
    public void onItemClick(View view, int position) {
        Intent i = new Intent(CategoryForSpending.this, DisplayCategory.class);
        i.putExtra("Category", adapter.getItem(position));
        i.putExtra("Username", "Ethan_Stanley");
        startActivityForResult(i, 1);


    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                String category = data.getStringExtra("category");
                Log.v("ETHANETHNA", category);
                ArrayList<ArrayList<String>> list = adapter.returnData();
                for(int x = 0; x < list.size(); x++){
                    if(list.get(x).get(0).equals(category)){
                        list.set(x, new ArrayList<>(Arrays.asList(category, "Complete")));
                        Log.v("Good", list.get(x).get(0));
                    }
                    Log.v("Bad", list.get(x).get(0));
                }
                Log.v("ArrayListttt", list.toString());
                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.workshopParticipants);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                adapter = new MyRecyclerViewAdapter(this, list);
                adapter.setClickListener(this);
                recyclerView.setAdapter(adapter);
                //adapter.getItem(position)
            }
        }
    }

}